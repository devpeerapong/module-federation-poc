declare function Counter({ initialCount }: {
    initialCount?: number;
}): import("react/jsx-runtime").JSX.Element;
export default Counter;
