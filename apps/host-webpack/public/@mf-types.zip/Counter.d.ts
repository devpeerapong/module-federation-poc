export * from './compiled-types/client/components/Counter';
export { default } from './compiled-types/client/components/Counter';